#include <iostream>
#include <cstring>
#include "abonent.h"
#include "abonentbook.h"

using namespace std;
int main()
{

    AbonentBook s;

    s.AddAbonent("charlie","?",7777777,7879879);
    s.AddAbonent("Q"," ",435,789);
    s.displayAbon("charlie");
    s.


}
