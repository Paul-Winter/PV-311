﻿#include <iostream>
#include "String.h"
using namespace std;

int main()
{
	String str1;
	String str2;
	str2.setSizeStr(160);
	String str3;
	str3.setStr("victory");
	
	str3.Display();

}

